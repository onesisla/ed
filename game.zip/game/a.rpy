init python:
    def toggle_fullscreen():
        renpy.config.fullscreen = not renpy.config.fullscreen
        renpy.restart()
